function onExecuted() {
	var ISI_input = document.getElementById("ISI_mycheckbox");
	if (ISI_input.checked) {
		ISI_input.checked = false;
		document.getElementById("iframee").contentWindow.postMessage({ open: false }, "https://fam.xyz/extension-12345678910");
	} else {
		document.getElementById("iframee").contentWindow.postMessage({ open: true }, "https://fam.xyz/extension-12345678910");
		ISI_input.checked = true;
	}
}

function findFrame() {
	const iframes = Array.from(document.querySelectorAll("iframe"));
	const framerIframe = iframes.find((iframe) => iframe.src.includes("framercanvas.com"));
	return { iframeSrc: framerIframe.src };
}



async function captureDivFromIframe(divID, tabId) {

	let result = await chrome.scripting.executeScript({
		target: { tabId: tabId },
		func: findFrame,
	});

	if (result) {
		console.log("result", result);
		chrome.scripting.executeScript({
			target: { tabId: tabId, allFrames: true },
			func: async (DIV) => {  // Notice the parameter DIV here
				
				const targetDiv = document.getElementById('id_'+DIV);
				
				if (targetDiv) {
					// Now use html2canvas or other methods to capture this div
          const canvas = await html2canvas(targetDiv);
          let img = canvas.toDataURL("image/webp", 0.9);
          console.log("img", img);
				}
			},
			args: [divID]
		});
	}
}


//toggle side panel when the icon is clicked int he menu bar
chrome.action.onClicked.addListener((tab) => {
	chrome.scripting.executeScript({
		target: { tabId: tab.id },
		func: onExecuted,
	});
});

//listen for messages from content.js
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
	if (request.action === "captureDiv") {
		captureDivFromIframe(request.divID, sender.tab.id);
	}
});
