

function loadFramer() {

  //create the image
  var famImg = document.createElement("img");
	famImg.setAttribute("class", "poop");
	famImg.setAttribute ("src", chrome.runtime.getURL("images/fam_bubble_default.svg"));

	//create the image holder
	var famDiv = document.createElement("div");
	famDiv.setAttribute("class", "poopz");
	famDiv.setAttribute("id", "famLogo");

  //create the clickDiv
  var clickDiv = document.createElement("input");
  clickDiv.setAttribute("class", "clickDiv");
  document.body.appendChild(clickDiv);

	//when logo is clicked, it will toggle the ISI_input
	famImg.addEventListener(
		"click",
		function () {
			if (ISI_input.checked) {
				ISI_input.checked = false;
				document.getElementById("iframee").contentWindow.postMessage({ open: false }, "https://fam.xyz/extension-12345678910");
			} else {
				document.getElementById("iframee").contentWindow.postMessage({ open: true }, "https://fam.xyz/extension-12345678910");
				ISI_input.checked = true;
			}
		},
		false
	);

	//mouse over logo event
  famDiv.addEventListener(
    "mouseenter",
    function () {
      famImg.setAttribute("src", chrome.runtime.getURL("images/fam_bubble_active.svg"));
    },
    false
  );
  //mouse leave logo event
  famDiv.addEventListener(
    "mouseleave",
    function () {
      famImg.setAttribute("src", chrome.runtime.getURL("images/fam_bubble_default.svg"));
    },
    false
  );

  //append famImg to famDiv, then famDiv to body
  famDiv.appendChild(famImg);
	document.body.appendChild(famDiv);
}

function toggleISI () {
  if (ISI_input.checked) {
    ISI_input.checked = false;
  } else {
    ISI_input.checked = true;
  }
}

if (window.location.hostname == "bubble.io" || window.location.hostname == "webflow.com" || window.location.hostname == "framer.com") {
	// create and add the html to canvas script to the head
	const html2canvasscript = document.createElement("script");
	//set the html2canvasscript src to the local file htmls2canvas.js
	html2canvasscript.src = chrome.runtime.getURL("html2canvas.js");
	html2canvasscript.type = "text/javascript";
	html2canvasscript.setAttribute("integrity", "");
	document.getElementsByTagName("head")[0].appendChild(html2canvasscript);

	var ISI_input = document.createElement("input");
	ISI_input.setAttribute("type", "checkbox");
	ISI_input.id = "ISI_mycheckbox";

	var ISI_label = document.createElement("label");
	ISI_label.setAttribute("for", "ISI_mycheckbox");
	ISI_label.setAttribute("class", "ISI_feedback-label");
	ISI_label.innerHTML = "Fam";

	var ISI_form = document.createElement("div");

	ISI_form.id = "ISI_CTN";
	ISI_form.innerHTML = `
  
  <div class="iframeholder" id="sandox" >

        <iframe id='iframee' allow="clipboard-read; clipboard-write" src="https://fam.xyz/extension-12345678910" frameborder="0" height="100%" width="100%"></iframe>
    </div>

    `;

	document.body.appendChild(ISI_input);
	document.body.appendChild(ISI_form);
	setTimeout(function () {
		//console.log(document.getElementById("iframee"));
		document.getElementById("iframee").contentWindow.postMessage({ host: window.location.hostname }, "https://fam.xyz/extension-12345678910");
	}, 4000);
}
if (window.location.pathname.includes(`page`)) {
	//console.log(window.location);
	/*add an event listner for mouse down events */
	document.addEventListener("mousedown", function (event) {
		//check if the event's target class contains context-menu-item
		if (!event.target.classList.contains("context-menu-item")) {
			//if not, grab the divs id and store it in a variable
			window.theDiv = event.target.id;
		}
	});

	//listen for changes to local storage. when a copy is created, caputre the copy and add it to window.a1var
	window.addEventListener(
		"storage",
		function async(event) {
			if (JSON.parse(event.newValue) instanceof Object === true) {
				let componentToCopy = JSON.parse(event.newValue).data;
				if (componentToCopy instanceof Array) {
					const frame = document.getElementById("iframee");

					window.scrollTo(0, 0);

					// Convert the div to image (canvas)
					html2canvas(document.getElementById(window.theDiv)).then(function (canvas) {
						// Get the image data as JPEG and 0.9 quality (0.0 - 1.0)
						let obj = {
							componentToCopy: componentToCopy,
							host: "bubble.io",
							image: canvas.toDataURL("image/jpeg", 0.9),
						};
						// //console.log(obj)
						frame.contentWindow.postMessage(obj, "https://fam.xyz/extension-12345678910");
					});
				}
			}
		},
		false
	);
	//listen to messages passed from the plugin.
	//this will allow you to either to copy to local storage from the bubble DB
	//or will allow you to close the slideout window.
	window.addEventListener(
		"message",
		function (e) {
			if (e.data.type === "copy") {
				// Get the sent data
				const data = e.data || {};
				if (data !== {}) {
					window.localStorage.setItem("bubble_element_clipboard", data.data);
				}
			} else if (e.data.type === "close") {
				//dispatch a click event to famImg
				const famImg = document.querySelector("#famLogo > img");
				const event = new MouseEvent("click", {
					view: window,
					bubbles: true,
					cancelable: true,
				});
				famImg.dispatchEvent(event);
			}
		},
		false
	);

	var leftBox = document.querySelector("body > div.body > div.main-tab-bar");

	//add a new div to the left box
	var famDiv = document.createElement("div");
	var div2 = document.createElement("div");

	famDiv.setAttribute("class", "poopz");

	var famImg = document.createElement("img");
	famImg.setAttribute("class", "poop");
	//when image is clicked, it will toggle the ISI_input
	famImg.addEventListener(
		"click",
		function () {
			if (ISI_input.checked) {
				ISI_input.checked = false;
				document.getElementById("iframee").contentWindow.postMessage({ open: false }, "https://fam.xyz/extension-12345678910");
			} else {
				document.getElementById("iframee").contentWindow.postMessage({ open: true }, "https://fam.xyz/extension-12345678910");
				ISI_input.checked = true;
			}
		},
		false
	);
	//set the image src from the image joe.png
	famImg.setAttribute("src", chrome.runtime.getURL("images/fam_bubble_default.svg"));

	famImg.addEventListener(
		"mouseenter",
		function () {
			famImg.setAttribute("src", chrome.runtime.getURL("images/fam_bubble_active.svg"));
		},
		false
	);
	famImg.addEventListener(
		"mouseleave",
		function () {
			famImg.setAttribute("src", chrome.runtime.getURL("images/fam_bubble_default.svg"));
		},
		false
	);
	famImg.setAttribute("height", "57px");
	famImg.setAttribute("width", "46px");
	famDiv.style.borderBottom = "1px solid #dcdcdc";
	famDiv.style.marginBottom = "5px";
	famImg.style.marginLeft = "auto";
	famImg.style.marginRight = "auto";
	famImg.style.paddingTop = "5px";

	famImg.style.display = "block";
	div2.setAttribute("class", "centerd");
	famDiv.appendChild(famImg);
	famDiv.setAttribute("id", "famLogo");
	famDiv.appendChild(div2);
	famDiv.style.height = "62px";
	famDiv.style.width = "60px";
	famDiv.style.zIndex = "9999999";
	famDiv.style.position = "fixed";
	famDiv.style.bottom = "24px";
	famDiv.style.left = "24px";
	//add a shadow to the famDiv
	famDiv.style.boxShadow = "0 0 10px rgba(0,0,0,0.2)";

	//append famDiv to body of the main page
	document.body.appendChild(famDiv);
	//find famDiv and print it to the console
	//console.log(document.querySelector("#famLogo"));
} else if (window.location.hostname == "webflow.com") {
	let webFlowIFrame;
	const waitForFrame = () => {
		if (window.frames["site-iframe-next"]) {
			webFlowIFrame = window.frames["site-iframe-next"];
		} else {
			setTimeout(waitForFrame, 50);
		}
	};
	waitForFrame();

	var thisIsABubbleCopyToClipboard = false;
	var deleteMe = true;
	//prep the work area visually.
	function waitForElement(elementPath, callback) {
		if (window.document.getElementsByClassName(elementPath)[0]) {
			let e = window.document.getElementsByClassName(elementPath)[0];
			callback(e);
		} else {
			setTimeout(function () {
				waitForElement(elementPath, callback);
			}, 100);
		}
	}

	waitForElement("left-sidebar-links", function (e) {
		let sideBar = e;

	

		let clickDiv = document.createElement("input");
		clickDiv.setAttribute("class", "clickDiv");
    document.body.appendChild(clickDiv);
    
    //create image holder
    let famDiv = document.createElement("div");
    famDiv.setAttribute("class", "famDiv");

    //create image
		let famImg = document.createElement("img");
		famImg.setAttribute("class", "famImg");
		famImg.setAttribute("src", chrome.runtime.getURL("images/fam_webflow_default.svg"));

    //append image to image holder.  then append image holder to the sidebar
		famDiv.appendChild(famImg);
		sideBar.appendChild(famDiv);
		

		//styling for the fam bbutton
		famDiv.addEventListener("click", toggleISI, false);

		famDiv.addEventListener(
			"mouseenter",
			function () {
				famImg.setAttribute("src", chrome.runtime.getURL("images/fam_webflow_active.svg"));
			},
			false
		);

		famDiv.addEventListener(
			"mouseleave",
			function () {
				famImg.setAttribute("src", chrome.runtime.getURL("images/fam_webflow_default.svg"));
			},
			false
		);
	});

	/*
  the following 3 functions are related to copying to or from the clipboard.
  
  when someone manually copies from webflow, someoneClickedCopyToClipboard will be fire. that will also paste the copied component so it is deleted. 
  
  */
	const deleteCopiedComponent = async function (e) {
		var itemWasFound = false;

		if (thisIsABubbleCopyToClipboard == false) {
			let componentJSON = e.clipboardData.getData("application/json");
			let component = JSON.stringify(componentJSON);
			setTimeout(() => {
				// window.document.querySelector('div[data-automation-id="designer-topbar-undo"]').click();
			}, 10);

			// document.querySelector("#designer-app-react-mount > div > div > div.wf-qcua98 > div.bem-TopBar > div > div.bem-TopBar_Body_Group.bem-TopBar_Body_Group-right > div:nth-child(2) > div > div:nth-child(1) > div")

			const theDIV = JSON.parse(componentJSON).payload.nodes[0]._id;
			const theDivClass = JSON.parse(componentJSON).payload.nodes[0].classes[0];
			const styles = JSON.parse(componentJSON).payload.styles;
			let divs = webFlowIFrame.contentWindow.document.querySelectorAll("div");

			var image;
			//find the div that matches the id of the copied component
			for (let i = 0; i < divs.length; i++) {
				let tempID = divs[i].getAttribute("data-w-id");

				if (tempID == theDIV) {
					itemWasFound = true;
					//console.log("match");
					document.removeEventListener("paste", deleteCopiedComponent);
					thisIsABubbleCopyToClipboard = false;
					var name;
					for (let e = 0; e < styles.length; e++) {
						if (styles[e]._id == theDivClass) {
							name = styles[e].name;
						}
					}

					html2canvas(divs[i])
						.then(function (canvas) {
							// Get the image data as JPEG and 0.9 quality (0.0 - 1.0)
							let img = canvas.toDataURL("image/webp", 0.9);

							let obj = {
								componentToCopy: component,
								host: "webflow.com",
								image: img,
								name: name,
							};
							const frame = document.getElementById("iframee");
							frame.contentWindow.postMessage(obj, "https://fam.xyz/extension-12345678910");
						})
						.catch(function (error) {
							console.error("oops, something went wrong!", error);
						});
				} else {
					document.removeEventListener("paste", deleteCopiedComponent);
					thisIsABubbleCopyToClipboard = false;
				}
			}

			if (itemWasFound == false) {
				let obj = {
					componentToCopy: component,
					host: "webflow.com",
					image: null,
					name: "Webflow Component",
				};
				const frame = document.getElementById("iframee");
				frame.contentWindow.postMessage(obj, "https://fam.xyz/extension-12345678910");
			}
		} else {
			//console.log("else");
		}
	};

	function someoneCopiedAnElementOnScreen(e) {
		document.getElementsByClassName("clickDiv")[0].focus();
		document.addEventListener("paste", deleteCopiedComponent, false);
		setTimeout(() => {
			document.execCommand("paste");
		}, 10);
	}

	function copyFromBubbleToClipboard(e) {
		if (e && e.clipboardData) {
			e.clipboardData.setData("application/json", JSON.parse(window.copiedJSON));
		}

		setTimeout(() => {
			window.removeEventListener("copy", copyFromBubbleToClipboard);
			document.addEventListener("copy", someoneCopiedAnElementOnScreen, false);
			thisIsABubbleCopyToClipboard = false;
		}, 150);
	}

	//document.execCommand('copy');

	document.addEventListener("copy", someoneCopiedAnElementOnScreen, false);

	//handle messages from the ifram/plugin
	window.addEventListener(
		"message",
		function (e) {
			if (e.data.type === "copy") {
				//console.log("copy coming from b ubble");
				window.copiedJSON = JSON.parse(e.data.data);
				thisIsABubbleCopyToClipboard = true;

				document.removeEventListener("copy", someoneCopiedAnElementOnScreen);
				document.removeEventListener("paste", deleteCopiedComponent);

				document.addEventListener("copy", copyFromBubbleToClipboard, false);

				setTimeout(() => {
					document.execCommand("copy");
				}, 150);
			} else if (e.data.type === "close") {
				//dispatch a click event to famImg
				window.document.querySelector("#designer-app-react-mount > div > div > div.left-sidebar > div > div.famDiv").click();
			}
		},
		false
	);
} else if (window.location.hostname == "framer.com") {
	loadFramer();

  function handleACopyEvent(e) {
    
    //focus on the clickDiv
    
    let componentCode = e.clipboardData.getData("text/html");
    //convert the compnonent code to html and store it in a variable
    let component = new DOMParser().parseFromString(componentCode, "text/html");
    //grab the first div in the component
    let componentDiv = component.querySelector("span");
    //from the first div, get the JSON from data-framer-pasteboard attribute
    let componentJSON = componentDiv.getAttribute("data-framer-pasteboard");
    //parse the JSON and store it in a variable
    componentJSON = JSON.parse(componentJSON);
    //grab the id of the component on the canvas to grab a screenshot of it
    let componentID = componentJSON.layers.tree.root.children[0].id;
    console.log('component id: id_' + componentID)
    window.div = 'id_' + componentID;
    chrome.runtime.sendMessage({ action: "captureDiv", divID: componentID });
  }



  document.addEventListener("copy",   function (e) {
    console.log(e)
		document.getElementsByClassName("clickDiv")[0].focus();
		document.addEventListener("paste", handleACopyEvent, false);
		setTimeout(() => {
			document.execCommand("paste");
		}, 10);
	}, false);

}
