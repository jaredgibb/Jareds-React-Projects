$(document).ready(function () {
	if (window.location.ancestorOrigins.length == 0) {
		var current_url = window.location.hostname.replace('www.','');
		chrome.runtime.sendMessage({msg: "add_url", url: current_url});
		chrome.storage.local.set({
			url: window.location.href
		});
	}
});