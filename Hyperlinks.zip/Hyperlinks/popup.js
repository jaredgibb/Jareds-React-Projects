function extractDomain(url) {
    // Create a temporary anchor element
    var a = document.createElement('a');
    // Set the href attribute of the anchor element to the URL
    a.href = url;
    // Use the hostname property of the anchor element to get the domain name
   const hostName = a.hostname.split('.')
    let domain
    if(hostName.length > 2){
         domain = hostName[1]
    } else {
         domain = hostName[0]
    }

    
    
    // Return the domain name
    
    return domain;
  }

chrome.tabs.query({
    active: true,
    lastFocusedWindow: true
}, function(tabs) {
    // and use that tab to fill in out title and url
    var tab = tabs[0];
    const url = tab.url;
    //grab the domain name from the url
  
    const iframe = document.getElementById('iframe-hyperlink');
    iframe.src = 'https://app.hyperlinks.com/extension' + '?source=' + extractDomain(url);

});